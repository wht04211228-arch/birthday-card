particlesJS("particles-js",{
particles:{
number:{value:100},
color:{value:"#ffffff"},
shape:{type:"circle"},
move:{speed:2}
}
});
const imgs =
document.querySelectorAll(".slider img");

let index=0;

imgs[0].style.display="block";

setInterval(()=>{
imgs[index].style.display="none";

index=(index+1)%imgs.length;

imgs[index].style.display="block";

},3000);
document.body.onclick=()=>{
document
.getElementById("bgm")
.play();
}
const container=document.body;

const fireworks=
new Fireworks.default(
container
);

fireworks.start();